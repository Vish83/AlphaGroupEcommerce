package com.e_com;

import java.util.Scanner;

public class AdminPage {
		
		public void getUserList() {
			String check1 = "P";
			String check2 = "R";
			String check3 = "U";
			Scanner scanner = new Scanner(System.in);

			System.out.println("welcome to Admin Page ");
			System.out.println("Select one from Given List");
			System.out.println("To Check  Product Quantity Enter letter P");
			System.out.println("To Check Registerd Users Enter letter R");
			System.out.println("To check user purchase history Enter letter U");

			String check = scanner.next();

			if (check.equals(check1)) {
				CheakQuantity checkQuantity = new CheakQuantity();
				checkQuantity.getProductQuantity();
			} else if (check.equals(check2)) {
				DisplayUserList displayUserList = new DisplayUserList();
				displayUserList.getUserList();
			} else if (check.equals(check3)) {
				UserPurchaseHistory userPurchaseHistory = new UserPurchaseHistory();
				userPurchaseHistory.getUserPurchaseHistory();
			} else {
				System.out.println("Invalid Input");
			}
			
		}
	}

