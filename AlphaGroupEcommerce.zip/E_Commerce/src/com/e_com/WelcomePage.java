package com.e_com;

	import java.util.Scanner;
public class WelcomePage {
	
		public int getWelcomeUser() {
			String signUp = "n";
			String registerd = "y";
			System.out.println("Welcome To E-commerce Platform");
			System.out.println("If you are a new user please press : n");
			System.out.println("If you are a registered user please press : y");
			Scanner scanner = new Scanner(System.in);
			String a = scanner.next();
			int number;
			if (a.equals(signUp)) {
				number = 1;

			} else {
				number = 0;

			}
			return number;

		}

	}

	


