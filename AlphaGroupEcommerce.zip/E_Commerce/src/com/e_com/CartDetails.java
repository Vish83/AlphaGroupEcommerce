package com.e_com;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class CartDetails {
	

		public void getCartDetails() {
			double sum = 0.0d;
			Scanner sc = new Scanner(System.in);
			try {
				Connection connection = new Utility_Connection().getConnection();
				Statement statement = null;
				Statement st = connection.createStatement();
				ResultSet rs = st.executeQuery("select * from products Order by product_Name");
				
				while (rs.next()) {

					System.out.println(" product_Id: " + rs.getInt(1) + "  \n product_Name: " + rs.getString(2)
							+ " \n product_description: " + rs.getString(3) + " \n price: " + rs.getString(4) + " \n quantity:"
							+ rs.getString(5));

					System.out.println();

				}
				System.out.println("Enter size of the cart");
				int cartsize = sc.nextInt();
				for (int i = 0; i < cartsize; i++) {
					System.out.println("Enter product id to add product to cart:");
					int id = sc.nextInt();

					System.out.println("Enter quantity of the selected product :");
					int quantity = sc.nextInt();
					Statement st1 = connection.createStatement();

					ResultSet rs1 = st1.executeQuery("select * from products where Product_Id=" + id + "");
					while (rs1.next()) {
						System.out.println("Name: " + rs1.getString(2) + "  Price: " + rs1.getInt(4));
						double total = +rs1.getInt(4) * quantity;
						System.out.println("Total: " + total);

						sum += total;

					}

				}
				System.out.println("grandtotal: " + sum);

			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		}




