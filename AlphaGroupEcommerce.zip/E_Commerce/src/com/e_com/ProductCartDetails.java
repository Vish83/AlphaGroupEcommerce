package com.e_com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class ProductCartDetails {


		public int choice() {

			int number;
			String b = "B";

			System.out.println("If you want buy products Enter letter : B");

			System.out.println("If you want to add products to Cart, then Enter any key.");
			Scanner scanner = new Scanner(System.in);
			String Choice = scanner.next();
			if (Choice.equals(b)) {
				number = 1;

				System.out.println("Confirm Username to continue shopping... ");
				// Scanner scanner=new Scanner(System.in);
				String user = scanner.next();
				buyProduct(user);
			} else {
				number = 0;
				CartDetails cartDetails = new CartDetails();
				cartDetails.getCartDetails();
			}

			return number;
		}

		void buyProduct(String user) {
			double sum = 0.0;
			Scanner sc = new Scanner(System.in);
			try {
				Connection connection = new Utility_Connection().getConnection();
				Statement statement = null;
				Statement st = connection.createStatement();
				ResultSet rs = st.executeQuery("select * from products Order by product_Name");

				while (rs.next()) {

					System.out.println(" productId: " + rs.getInt(1) + "  \n productName: " + rs.getString(2)
							+ " \n productDesc: " + rs.getString(3) + " \n price: " + rs.getString(4) + " \n quantity:"
							+ rs.getString(5));

					System.out.println();

				}
				System.out.println("How many products do you want to buy?");
				int buyP = sc.nextInt();
				for (int i = 0; i < buyP; i++) {
					System.out.println("Enter product id :");
					int id = sc.nextInt();

					System.out.println("Enter product quantity :");
					int quantity = sc.nextInt();
					Statement st1 = connection.createStatement();

					ResultSet rs1 = st1.executeQuery("select * from products where product_Id=" + id + "");
					while (rs1.next()) {
						System.out.println("Name: " + rs1.getString(2) + "  Price: " + rs1.getInt(4));
						double total = +rs1.getInt(4) * quantity;
						System.out.println("Total: " + total);
						int oQuantity = rs1.getInt(5);
						sum +=total;

						String quant = String.valueOf(quantity);
						String price = String.valueOf(rs1.getInt(4));
						String totalS = String.valueOf(sum);

						PreparedStatement preparedStatement = connection.prepareStatement(
								"insert into purchasehistory(userName,product_Name,productQuantity,price,totalPrice)values(?,?,?,?,?)");
						preparedStatement.setString(1, user);
						preparedStatement.setString(2, rs1.getString(2));
						preparedStatement.setString(3, quant);
						preparedStatement.setString(4, price);
						preparedStatement.setString(5, totalS);
						preparedStatement.executeUpdate();

						// for minus quantity
						int uQuantity = oQuantity - quantity;
						String updateQ = String.valueOf(uQuantity);

						PreparedStatement preparedStatement1 = connection
								.prepareStatement("update products set quantity=? where product_Name=?");
						preparedStatement1.setString(1, updateQ);
						preparedStatement1.setString(2, rs1.getString(2));
						preparedStatement1.executeUpdate();

					}

				}
				System.out.println("grandtotal: " + sum);

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

	}

