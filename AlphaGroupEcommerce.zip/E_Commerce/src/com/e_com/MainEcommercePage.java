package com.e_com;

import com.e_com.LoginPage;
import com.e_com.User_Registration;
import com.e_com.WelcomePage;

public class MainEcommercePage {


		public static void main(String[] args) {
			WelcomePage welcomePage = new WelcomePage();
			int result = welcomePage.getWelcomeUser();
			
			if (result==1) {	
				User_Registration userRegistration=new User_Registration();
				userRegistration.getUserDetails();
			}else {
				LoginPage loginPage=new LoginPage();
				loginPage.signIn();
			}
		}
	}

