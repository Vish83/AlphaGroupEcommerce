package com.e_com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class LoginPage {
	

		String userName1;
		String password2;
		String Admin = "admin";
		String Apassword = "admin123";

		LoginPage() {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Hello,please Enter The Login Details");
			System.out.println("Please Enter the Username");
			userName1 = scanner.next();
			System.out.println("Please Enter the Password");
			password2 = scanner.next();

		}

		public void signIn() {
			if (userName1.equals(Admin) && password2.equals(Apassword)) {
				AdminPage adminMethods = new AdminPage();
				adminMethods.getUserList();

			} else {
				checkExistingUser();
			}

		}

		public void checkExistingUser() {
			try {
				Connection connection = new Utility_Connection().getConnection();
				PreparedStatement preparedStatement = null;
				preparedStatement = connection.prepareStatement("select Pass_word from user_Details where userName=?");
				preparedStatement.setString(1, userName1);
				ResultSet resultSet = preparedStatement.executeQuery();
				while (resultSet.next()) {
					String dbPassword = resultSet.getString(1);
					if (dbPassword.equals(password2)) {
						
						ProductCartDetails pcd = new ProductCartDetails();
						pcd.choice();

					} else {
						System.out.println("Invalid Username or Password");
						LoginPage loginPage=new LoginPage();
						loginPage.signIn();
					}

				}
				String dbPassword = resultSet.getString(1);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}



