package com.e_com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class User_Registration {


		public void getUserDetails() {

			UserDetails userdetails = new UserDetails();
			System.out.println("Hello, Welcome to  Registration Page of E-commerce Platform , Please enter Details..");

			System.out.println("Enter the First Name");
			Scanner scanner = new Scanner(System.in);
			userdetails.setFirstName(scanner.next());

			System.out.println("Enter the Last Name");
			userdetails.setLastName(scanner.next());

			System.out.println("Enter the Email Id");
			userdetails.setEmailId(scanner.next());

			System.out.println("Enter the Mobile Number");
			userdetails.setMobileNumber(scanner.next());

			System.out.println("Enter the Username");
			userdetails.setUserName(scanner.next());

			System.out.println("Enter the Password");
			userdetails.setPassword(scanner.next());

			User_Registration userregister = new User_Registration();
			userregister.getPassToDatabase(userdetails.getFirstName(), userdetails.getLastName(), userdetails.getEmailId(),
					userdetails.getMobileNumber(), userdetails.getUserName(), userdetails.getPassword());

		}

		public void getPassToDatabase(String firstName, String lastName, String emailId, String mobileNumber,
				String userName, String password) {

			Connection connection = new Utility_Connection().getConnection();
			PreparedStatement preparedStatement = null;
			try {
				
				preparedStatement = connection
						.prepareStatement("insert into user_details(firstName,lastName,emailId,mobileNumber,userName,pass_word)"
								+ "values(?,?,?,?,?,?)"
								);
				preparedStatement.setString(1, firstName);
				preparedStatement.setString(2, lastName);
				preparedStatement.setString(3, emailId);
				preparedStatement.setString(4, mobileNumber);
				preparedStatement.setString(5, userName);
				preparedStatement.setString(6, password);
				preparedStatement.executeUpdate();

				System.out.println(" Thank You ! " + userName + ", You Are Registered  successfully...");
				LoginPage loginPage = new LoginPage();
				loginPage.signIn();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}



