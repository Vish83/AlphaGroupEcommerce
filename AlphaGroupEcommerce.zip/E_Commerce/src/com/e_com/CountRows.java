package com.e_com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CountRows {



		public int getRowCount() {
			PreparedStatement preparedStatement = null;
			int count = 0;
			
			try {
				Connection connection = new Utility_Connection().getConnection();
				preparedStatement = connection.prepareStatement("Select count*from  products ");

				ResultSet resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					count = resultSet.getInt(1);

				}
			} catch (Exception e) {
				e.getMessage();

			} finally {
				try {
					preparedStatement.close();

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			return count;
		}

	}

