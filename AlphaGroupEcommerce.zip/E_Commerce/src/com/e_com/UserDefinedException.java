package com.e_com;

public class UserDefinedException extends Exception{

	

		public UserDefinedException(String s) {
			super();
			
		}

		

	}




