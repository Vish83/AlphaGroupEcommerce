package com.e_com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class DisplayUserList {

		public void getUserList() {

			try {

				Connection connection = new Utility_Connection().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("Select firstName,lastName from user_Details");
				ResultSet resultSet = preparedStatement.executeQuery();
				System.out.println("Registerd User List---->>>");

				while (resultSet.next()) {

					System.out.println(resultSet.getString(1) + " " + resultSet.getString(2));

				}
			} catch (Exception e) {
				System.out.println(e);
			}

		}

	}

