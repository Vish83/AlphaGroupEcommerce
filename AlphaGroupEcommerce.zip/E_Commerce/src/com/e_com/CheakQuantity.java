package com.e_com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class CheakQuantity {

		void getProductQuantity() {
			System.out.println("Enter ProductID");
			Scanner scanner = new Scanner(System.in);
			int id = scanner.nextInt();
			Statement statement = null;
			PreparedStatement preparedStatement = null;
			try {
				Connection connection = new Utility_Connection().getConnection();

				Statement st = connection.createStatement();
				CountRows countRows = new CountRows();
				int count = countRows.getRowCount();

				if (id < 0 || id > count) {
					throw new UserDefinedException("Invalid Input");
				}
				preparedStatement = connection.prepareStatement("Select quantity from products where Product_Id=? ");

				preparedStatement.setInt(1, id);

				ResultSet resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					System.out.println("Product Quantity =" + resultSet.getString(1));
				}

			} catch (Exception e) {
				e.getMessage();

			} finally {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				scanner.close();

			}

		}
	}

