package com.e_com;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class UserPurchaseHistory {

		public void getUserPurchaseHistory() {
			try {
				System.out.println("Enter username to search product history");
				Scanner scanner = new Scanner(System.in);
				String username = scanner.next();

				Connection connection = new Utility_Connection().getConnection();
				PreparedStatement preparedStatement = connection
						.prepareStatement("Select *from purchasehistory where userName=?");
				preparedStatement.setString(1, username);
				ResultSet resultSet = preparedStatement.executeQuery();
				System.out.println("The User Purchase Product Histroy is...");

				while (resultSet.next()) {

					System.out.println("SRNO : " + resultSet.getString(1) + ",Username : " + resultSet.getString(2)
							+ ",Product Name : " + resultSet.getString(3) + ",Quantity : " + resultSet.getString(4)
							+ " ,Unit Price : " + resultSet.getString(5) + ",Total Price : " + resultSet.getString(6));

				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

